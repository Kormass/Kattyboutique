package com.campusland.exceptiones.productoexceptions;

public class ProductoNullException extends Exception {
    public ProductoNullException(String mensaje) {
        super(mensaje);
    }


    
}
