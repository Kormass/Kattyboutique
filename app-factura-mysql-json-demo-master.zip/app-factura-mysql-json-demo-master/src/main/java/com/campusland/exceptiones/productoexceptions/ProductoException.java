package com.campusland.exceptiones.productoexceptions;

public class ProductoException extends Exception{

    public ProductoException(String mensaje) {
        super(mensaje);
    }
    
}
